---
layout: page
title: Impressum
permalink: /credits/
nav: true
order: 5
---

Verantwortlich:

Dr. Andreas Kuczera

Regesta Imperii

Justus-Liebig Universität Gießen

Historisches Institut, Mittelalter

Otto-Behaghel-Str. 10

D-35394 Gießen

Haus C Raum 244a

<mailto:andreas.kuczera@adwmainz.de>
https://orcid.org/0000-0003-1020-507X
www.graphentechnologien.de

Letzte Aktualisierung: August 2018

<a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" href="http://purl.org/dc/dcmitype/Text" property="dct:title" rel="dct:type">Graphentechnologien in den Digitalen Geisteswissenschaften</span> von <a xmlns:cc="http://creativecommons.org/ns#" href="https://orcid.org/0000-0003-1020-507X" property="cc:attributionName" rel="cc:attributionURL">Andreas Kuczera</a> ist lizensiert unter einer <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International Lizenz</a>.
