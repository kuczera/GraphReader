---
title: Graphentechnologien in den Digitalen Geschichtswissenschaften
subtitle: Ein Studienbegleitbuch
author:
- Andreas Kuczera
lang: de
---
