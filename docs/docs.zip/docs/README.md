# Graphentechnologien in den digitalen Geisteswissenschaften
Reader zum DH-Modul Graphentechnologien in den digitalen Geschichtswissenschaften
https://kuczera.github.io/GraphReader/
